﻿# NeuralSpace

NeuralSpace is a patient-centered neurotechnology platform built to help people understand, manage, and improve their cognitive and brain-health outcomes through a single digital experience.

The product blends personal health tracking, encrypted medical record management, clinician access, neural learning resources, wellness protocols, and geospatial research data into one ecosystem designed for modern brain health care.

## Purpose

The platform is designed to make brain health more accessible, proactive, and personalized.

It gives each user a place to:
- manage their neuro health profile and preferences
- upload and review personal medical records
- track cognition and stress trends over time
- explore brain health data across regions and communities
- connect with clinicians and care pathways
- access learning resources and wellness programs
- browse medical tourism options and care itineraries
- view wallet and reward data tied to their account

## Core product goals

1. Personalize care
   Every user sees their own records, metrics, subscriptions, and activity rather than shared placeholder data.

2. Increase trust and privacy
   Medical data can be uploaded, encrypted, and linked to a user account with privacy-first handling.

3. Connect ecosystem services
   Patients can move between dashboard, health wallet, onboarding, insurance, messaging, and care activity without losing context.

4. Surface actionable insight
   The dashboard and MySpace views combine cognitive metrics, progress, and region-level health index data to make patterns easier to understand.

## Main modules

- Dashboard: summary analytics and recent uploads
- MySpace: personal overview with NBHDI map, records, and account metrics
- Clinical care: clinician access and e-MR uploads
- Health wallet: token balance and transaction history
- Insurance: coverage plans and subscriptions
- Medical tourism: local and international care destinations
- Wellness: protocol sync and personal health routines
- Neurolearn: training modules and progress tracking
- Greenspace: membership and community access
- Profile: account details and state management

## Tech stack

- Django
- SQLite (default local app database)
- Django templates and custom theme CSS
- Leaflet for the geospatial map
- Chart.js for analytics visualization

## Local setup

1. Create and activate a virtual environment
2. Install requirements:
   pip install -r requirements.txt
3. Run migrations:
   python manage.py migrate
4. Start the app:
   python manage.py runserver

## Typical workflow

- create an account via signup
- complete onboarding
- visit the dashboard and MySpace pages
- upload medical reports in Clinical Care
- review wallet activity and insurance coverage
- track wellness and learning progress over time

## Notes

This project is designed as a practical MVP for a neurohealth platform. It uses real Django models and user-scoped data so that each authenticated account reflects its own records and activity.
